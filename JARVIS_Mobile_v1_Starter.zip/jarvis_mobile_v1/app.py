import os
import json
import urllib.request
import urllib.error
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

SYSTEM_PROMPT = """
You are JARVIS, a helpful bilingual Hindi-English personal AI assistant.
Reply in the language the user uses, or naturally mix Hindi and English when useful.
You can help with coding, business planning, market education, research, and defensive cybersecurity.
Cybersecurity boundary: only explain legal, authorized security learning and defensive testing on systems
the user owns or has explicit permission to assess. Do not help break into accounts, steal data, evade
detection, deploy malware, or attack third-party systems.
Trading boundary: provide educational analysis and paper-trading ideas only; do not execute trades,
promise returns, or present predictions as certainty. Ask the user to verify important decisions.
Never claim you performed an action unless a connected tool actually did it.
Be clear when you are uncertain. Do not ask for passwords, API keys, or other secrets in chat.
"""

@app.get("/")
def home():
    return render_template("index.html")

@app.get("/api/status")
def status():
    return jsonify({
        "app": "JARVIS Mobile v1.0",
        "api_configured": bool(os.getenv("OPENAI_API_KEY")),
        "model": os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
    })

@app.post("/api/chat")
def chat():
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return jsonify({"error": "Server par OPENAI_API_KEY set nahi hai. README ke setup steps dekhein."}), 503

    data = request.get_json(silent=True) or {}
    message = (data.get("message") or "").strip()
    history = data.get("history") or []
    if not message:
        return jsonify({"error": "Pehle message likhiye."}), 400
    if len(message) > 8000:
        return jsonify({"error": "Message bahut lamba hai. 8000 characters se kam rakhein."}), 400

    # Keep only a short recent conversation to control cost and context size.
    input_items = []
    for item in history[-8:]:
        role = item.get("role")
        content = item.get("content", "")
        if role in ("user", "assistant") and isinstance(content, str):
            input_items.append({"role": role, "content": content[:4000]})
    input_items.append({"role": "user", "content": message})

    payload = {
        "model": os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
        "instructions": SYSTEM_PROMPT,
        "input": input_items,
        "max_output_tokens": 900
    }
    req = urllib.request.Request(
        "https://api.openai.com/v1/responses",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        },
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as response:
            result = json.loads(response.read().decode("utf-8"))
        answer = result.get("output_text")
        if not answer:
            chunks = []
            for output in result.get("output", []):
                for content in output.get("content", []):
                    if content.get("type") == "output_text":
                        chunks.append(content.get("text", ""))
            answer = "\n".join(chunks).strip()
        if not answer:
            answer = "Mujhe is baar readable response nahi mila. Dobara try karein."
        return jsonify({"answer": answer})
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:1200]
        return jsonify({"error": f"AI API error ({exc.code}): {detail}"}), 502
    except Exception as exc:
        return jsonify({"error": f"Connection error: {str(exc)}"}), 502

if __name__ == "__main__":
    port = int(os.getenv("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, debug=False)

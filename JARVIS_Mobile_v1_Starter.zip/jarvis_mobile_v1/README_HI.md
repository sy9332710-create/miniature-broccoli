# JARVIS Mobile v1.0 — Hindi setup

Yeh Android browser se use karne ke liye ek mobile-friendly starter project hai.
Is version mein chat + AI brain hai. Voice, coding tools, security lab, paper trading
aur business integrations agle milestones mein add honge.

## Mobile se run karne ka aasan tareeqa

1. GitHub ya Replit par account banayein.
2. Is ZIP ko extract karke project files upload karein, ya GitHub repository mein files add karein.
3. Python environment select karein.
4. Terminal mein chalayein: `pip install -r requirements.txt`
5. Hosting platform ke **Secrets / Environment Variables** mein:
   - `OPENAI_API_KEY` = apni API key
   - `OPENAI_MODEL` = `gpt-4.1-mini` (ya apne account mein available model)
6. Run command: `gunicorn app:app --bind 0.0.0.0:5000`
7. Platform ka generated web URL Android Chrome mein kholein.

## Security

- API key ko `app.py`, HTML, GitHub repository, screenshot ya chat mein paste na karein.
- Sirf server-side Secrets mein rakhein.
- Is starter mein AI response generate hota hai; yeh khud se accounts, devices, trades ya websites par action nahi leta.
- Cybersecurity help authorized systems aur defensive learning tak limited hai.
- Trading module abhi sirf educational/paper-trading planning ke liye hai.

## Local test (optional)

Python 3.10+ par:
`pip install -r requirements.txt`
`python app.py`
Phir browser mein `http://127.0.0.1:5000` kholein.

## Next milestones

1. Hindi/English voice input and speech output
2. Coding workspace with safe file/project tools
3. Defensive cybersecurity learning lab
4. Historical-data paper trading simulator
5. Business planner and inventory/profit calculator
6. Authentication, usage limits, and persistent memory
